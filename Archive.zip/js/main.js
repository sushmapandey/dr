

/*=====================================
=            video filter             =
=====================================*/

(function(){
    let filter = '';
    const typeLinks = document.querySelectorAll('.typeLink a');
    const catlinks = document.querySelectorAll('.catlink');
    const productCols = document.querySelectorAll('.inds');
    
    // for top menu filtering
    for(let catlink of catlinks){
      catlink.onclick = function(){
        const thisText = this.textContent;
        for(let prdCol of productCols){
          const thisAttr = prdCol.getAttribute('id');

        if (filter) {
          if(thisAttr.toUpperCase().includes(thisText.toUpperCase()) && thisAttr.toUpperCase().includes(filter.toUpperCase())){
              prdCol.style.display = 'flex'; 
            }
            else{
             prdCol.style.display = 'none';
            }
        } else {
          if(thisAttr.toUpperCase().includes(thisText.toUpperCase())){
            prdCol.style.display = 'flex'; 
          }
          else{
           prdCol.style.display = 'none';
          }
        }
      }     
    }
  }
  // for box filtering
  for(let typeLink of typeLinks){
    typeLink.onclick = function(){
      const thisText = this.textContent;
      filter = 'thisText';
      for(let prdCol of productCols){
        const thisAttr = prdCol.getAttribute('id');
        if(thisAttr.toUpperCase().includes(thisText.toUpperCase())){
          prdCol.style.display = 'block'; 
        }
        else{
          prdCol.style.display = 'none';
        }
      }     
    }
  }
})();

/*=====  End of video filter   ======*/




$(document).ready(function(){

  /*====================================
  =         scroll fixed header            =
  ====================================*/


  $(window).scroll(function() {
    if ($(window).scrollTop() >= 300){  
        $('.dj-header').addClass("fixed-top");
        $('.dj-header').addClass("scroll-logo");
        $('.header-logo').css("display", "none");
        $('.scroll-logo').css("display", "block");
      }
      else{
        $('.dj-header').removeClass("fixed-top");
        $('.header-logo').css("display", "block");
        $('.scroll-logo').css("display", "none");
      }  
  }); 

// fixed header for inner pages

$(window).scroll(function() {
  if ($(window).scrollTop() >= 30){  
      $('.dj-inner-header').addClass("fixed-top");
      $('.dj-inner-header').addClass("scroll-logo");
    }
    else{
      $('.dj-inner-header').removeClass("fixed-top");
    }  
}); 

      
  /*=====  End of fixed header  ======*/



  /*======================================
  =            Hamburger Menu            =
  ======================================*/

  $(".ham").click(function() {
    $('.dj-menu-link').slideToggle();
    $(this).toggleClass('active');
    $(this).toggleClass('dj-close');
    
  });

  /*=====  End of Hamburger Menu  ======*/

  

  




//video gallery
/*=====================================
=            Video gallery            =
=====================================*/

$('.filters ul li').click(function(){
  $('.filters ul li').removeClass('active');
  $(this).addClass('active');
  
  var data = $(this).attr('data-filter');
  $grid.isotope({
    filter: data
  })
});

var $grid = $(".grid").isotope({
  itemSelector: ".all",
  percentPosition: true,
  masonry: {
    columnWidth: ".all"
  }
})

/*=====  End of Video gallery  ======*/



/*===============================
=            Gallery with pop up            =
===============================*/

$(".owl-carousel").owlCarousel({
  loop: true,
  margin: 10,
  autoplay: true,
  nav: true,
  navText : ["<i class='fas fa-chevron-circle-left'></i>","<i class='fas fa-chevron-circle-right'></i>"],
  responsive: {
    0: {
      items: 1
    },
    600: {
      items: 3
    },
    1000: {
      items: 3
    }
  }
});






/*=====  End of Gallery with pop up  ======*/






});










