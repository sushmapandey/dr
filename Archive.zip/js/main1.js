

$(document).ready(function(){

  // Music
  /*=============================
  =            Music            =
  =============================*/
  
  var swiper = new Swiper('.swiper-container', {
    effect: 'coverflow',
    grabCursor: true,
    centeredSlides: true,
    slidesPerView: 'auto',
    coverflowEffect: {
      rotate: 50,
      stretch: 0,
      depth: 100,
      modifier: 1,
      slideShadows : true,
    },
    pagination: {
      el: '.swiper-pagination',
    },
  });
  
  /*=====  End of Music  ======*/
  



  /*===============================
  =            Gallery            =
  ===============================*/
  

  // Instantiate the Bootstrap carousel
$('.multi-item-carousel').carousel({
  interval: false
});

// for every slide in carousel, copy the next slide's item in the slide.
// Do the same for the next, next item.
$('.multi-item-carousel .item').each(function(){
  var next = $(this).next();
  if (!next.length) {
    next = $(this).siblings(':first');
  }
  next.children(':first-child').clone().appendTo($(this));
  
  if (next.next().length>0) {
    next.next().children(':first-child').clone().appendTo($(this));
  } else {
    $(this).siblings(':first').children(':first-child').clone().appendTo($(this));
  }
});
  var swiper = new Swiper('.gallery-slider', {
    slidesPerView: 3,
    centeredSlides: true,
    spaceBetween: 30,
    pagination: {
      el: '.swiper-pagination',
      type: 'fraction',
    },
    navigation: {
      nextEl: '.swiper-button-next',
      prevEl: '.swiper-button-prev',
    },
    virtual: {
      slides: (function () {
        var slides = [];
        for (var i = 0; i < 600; i += 1) {
          slides.push('Slide ' + (i + 1));
        }
        return slides;
      }()),
    },
  });
  document.querySelector('.slide-1').addEventListener('click', function (e) {
    e.preventDefault();
    swiper.slideTo(0, 0);
  });
  document.querySelector('.slide-250').addEventListener('click', function (e) {
    e.preventDefault();
    swiper.slideTo(249, 0);
  });
  document.querySelector('.slide-500').addEventListener('click', function (e) {
    e.preventDefault();
    swiper.slideTo(499, 0);
  });
  


  /*=====  End of Gallery  ======*/
  

  

/*======================================
=            Hamburger Menu            =
======================================*/

$(".ham").click(function() {
  $('.dj-menu-link').slideToggle();
  $(this).toggleClass('active');
  $(this).toggleClass('dj-close');
  
});

/*=====  End of Hamburger Menu  ======*/




//video gallery
/*=====================================
=            Video gallery            =
=====================================*/

$('.filters ul li').click(function(){
  $('.filters ul li').removeClass('active');
  $(this).addClass('active');
  
  var data = $(this).attr('data-filter');
  $grid.isotope({
    filter: data
  })
});

var $grid = $(".grid").isotope({
  itemSelector: ".all",
  percentPosition: true,
  masonry: {
    columnWidth: ".all"
  }
})

/*=====  End of Video gallery  ======*/



/*====================================
=         scroll fixed header            =
====================================*/


$(window).scroll(function() {
  if ($(this).scrollTop() >= 500){  
      $('dj-header').addClass("sticky");
    }
    else{
      $('dj-header').removeClass("sticky");
    }
  });
    
    
/*=====  End of fixed header  ======*/



});





/*=============================================
=            active-class            =
=============================================*/

$(document).ready(function(){
  $("ul li").click(function(){
    $("ul li.active").removeClass("active");
    $(this).addClass("active")
  })
});

/*=====  End of active-class  ======*/