<?php
/**
 Template Name: gallery template
 */

?>


<div class="dj-title">
  <h2>Latest <br><span> gallery</span></h2>
</div>
<div class="owl-carousel-wrap">
  <div class="owl-carousel owl-theme">
    <?php $gallery = new WP_Query('post_type=galleries&posts_per_page=-1&orderby=date&order=DESC'); ?>
    <?php if ($gallery->have_posts() ) : while ($gallery->have_posts() ) : $gallery->the_post(); ?>
    <div class="item">
      <img src="<?php the_post_thumbnail_url(); ?>" alt="Dj Gallery" data-darkbox="<?php the_post_thumbnail_url(); ?>" data-darkbox-group="one" />
    </div>
  <?php endwhile; endif;  wp_reset_postdata(); ?>
  </div>
</div>

