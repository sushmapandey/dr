<?php
/**
 * Sample implementation of the Custom Header feature
 *
 * You can add an optional custom header image to header.php like so ...
 *
	<?php the_header_image_tag(); ?>
 *
 * @link https://developer.wordpress.org/themes/functionality/custom-headers/
 *
 * @package dj
 */

/**
 * Set up the WordPress core custom header feature.
 *
 * @uses dj_header_style()
 */


function create_post_type() {
	add_theme_support('post-thumbnails');
	add_post_type_support( 'galleries', 'thumbnail' );  
  register_post_type( 'galleries',
    array(
      'labels' => array(
        'name' => __( 'Gallery' ),
        'singular_name' => __( 'Gallery' )
      ),
      'public' => true,
      'has_archive' => true,
    )
  );
}
add_action( 'init', 'create_post_type' );
	add_theme_support('post-thumbnails');