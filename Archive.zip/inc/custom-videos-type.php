<?php
/**
 * Sample implementation of the Custom Header feature
 *
 * You can add an optional custom header image to header.php like so ...
 *
	<?php the_header_image_tag(); ?>
 *
 * @link https://developer.wordpress.org/themes/functionality/custom-headers/
 *
 * @package dj
 */

/**
 * Set up the WordPress core custom header feature.
 *
 * @uses dj_header_style()
 */


function create_video_type() {
	add_theme_support('post-thumbnails');
	add_post_type_support( 'videos', 'thumbnail' );  
  register_post_type( 'videos',
    array(
      'labels' => array(
        'name' => __( 'Videos' ),
        'singular_name' => __( 'Video' )
      ),
      'public' => true,
      'has_archive' => true,
    )
  );
}
add_action( 'init', 'create_video_type' );
	add_theme_support('post-thumbnails');