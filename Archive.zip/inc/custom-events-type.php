<?php
/**
 * Sample implementation of the Custom Header feature
 *
 * You can add an optional custom header image to header.php like so ...
 *
	<?php the_header_image_tag(); ?>
 *
 * @link https://developer.wordpress.org/themes/functionality/custom-headers/
 *
 * @package dj
 */

/**
 * Set up the WordPress core custom header feature.
 *
 * @uses dj_header_style()
 */


function create_event_type() {
	add_theme_support('post-thumbnails');
	add_post_type_support( 'events', 'thumbnail' );  
  register_post_type( 'events',
    array(
      'labels' => array(
        'name' => __( 'Events' ),
        'singular_name' => __( 'Event' )
      ),
      'public' => true,
      'has_archive' => true,
    )
  );
}
add_action( 'init', 'create_event_type' );
	add_theme_support('post-thumbnails');